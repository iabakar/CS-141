s = ['Eve', 'Alice', 'Bob',"red", "blue", "green","red", "blue", "green"]

for i in range (len(s)):
    if s[i] == "red":
        print(s[i])
    else:
        # print(s[i])
        pass