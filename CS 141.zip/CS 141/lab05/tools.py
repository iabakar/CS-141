"""
identify the optimal new store location
compute the sum of the distances to each office.
File: tools.py
Author: Issah A.
"""


def read_data():
    """
    Ask user to enter file containing the business locations
    open the file and read the data.
    Get the business locations and append them to new list 
    return the new list of the business locations as int    
    
    """
    file = input("Enter data file:")
    numbers = []
    with open(file) as f:
        for line in f:
            data = line.strip().split(" ")
            numbers.append(int(data[1]))
    return numbers


def find_location(data):
    """
    Get the length of data
    and return the optimal location
    
    
    """
    if len(data) % 2 == 1:
        return data[(len(data) - 1) // 2]
    else:
        return ((data[len(data) // 2]) + (data[len(data) // 2 - 1])) / 2


# mid = find_location(data)
def sum_dif(data, mid):
    """
    takes data and mid point as arguments 
    return the sum of the distances to each offices
    """
    total = 0
    for i in data:
        total += abs(i - mid)
    return total
