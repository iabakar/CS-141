"""
identify the optimal new store location
compute the sum of the distances to each office.
File: storelocation.py
Author: Issah A.
"""

import time
from tools import *


def quick_select(data):
    """
    quick_select :
    sort list by choosing one element as a pivot and partitioning the data in two based on the pivot.
    Parameters:
        data - the list of data to sort
    post-conditions:
        The data list is in sorted order.
    
    
    """
    if len(data) <= 1:
        return data
    else:
        pivot = data.pop()  # chose pivot as the last value
    smaller_list = []
    larger_list = []

    for i in data:
        if i > pivot:  # check to see if pivot is greater then the i, and append it to the larger list
            larger_list.append(i)
        else:  # if not it adds the values to the smaller list
            smaller_list.append(i)
    return quick_select(smaller_list) + [pivot] + quick_select(larger_list)


def optimal_loc(data):
    """
    pass the list of data to ins_sort to sort the numbers.
    get the sorted list and pass it to find_location to find the optimal location
    returns the best location    
    """

    x = find_location(data)

    return x


def main():
    """
    call read_data funtion to get the data.
    pass the data to the optimal_loc function to find the optimal location.
    pass the data and the optimal location to sum_dif to get the sum of distannces to the new store.
    """
    data_file = read_data()

    start = time.perf_counter()
    data = quick_select(data_file)

    optimal = optimal_loc(data)
    sum = sum_dif(data, optimal)
    elapsed = time.perf_counter() - start

    print("Optimum new store location:", optimal)
    print("Sum of distances to the new store:", sum)
    print("Elapsed time:quick select (msec)", elapsed, "msec")


if __name__ == "__main__":
    main()
