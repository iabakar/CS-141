"""
identify the optimal new store location
compute the sum of the distances to each office.
File: storelocation.py
Author: Issah A.
"""

import time
from insertion import insertion_sort as ins_sort
from tools import *


def optimal_loc(data):
    """
    pass the list of data to ins_sort to sort the numbers.
    get the sorted list and pass it to find_location to find the optimal location
    returns the best location    
    """
    # data = ins_sort(data)
    x = find_location(data)

    return x


def main():
    """
    call read_data funtion to get the data.
    pass the data to the optimal_loc function to find the optimal location.
    pass the data and the optimal location to sum_dif to get the sum of distannces to the new store.
    """
    data_file = read_data()

    start = time.perf_counter()
    data = ins_sort(data_file)

    optimal = optimal_loc(data)
    sum = sum_dif(data, optimal)
    elapsed = time.perf_counter() - start

    print("Optimum new store location:", optimal)
    print("Sum of distances to the new store:", sum)
    print("Elapsed time: insertion sort (msec)", elapsed * 1000, "msec")

    # print("Elapsed time: insertion sort (msec)", elapsed * 1000, "msec")


if __name__ == "__main__":
    main()
