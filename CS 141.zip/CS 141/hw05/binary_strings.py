""" 
file: binary_strings.py
description: convert strings to binary and binary to strings
language: python3
author: Issah A 
"""


def binary_to_ascii7bits(binarystr):
    """
    purpose:takes a binary string argument and returns a string that is the concatenation of the ASCII.
    post-condition: set n = 7 since n is the number of blocks we want to converts each 7 bit substring into a decimal
    number.
    pre-condition:takes a binary string argument and pass it to FindDecimal fucntion to converts each 7 bit
    substring into a decimal number and return decimal after that, the function uses built in function char to print
    an ASCII character.

    """
    words = ''
    n = 7
    length = len(binarystr)  # get the length of string argumnet
    for i in range(0, length, n):
        binary = (binarystr[i:i + n])  # slices the string into chunks or blocks of 7 bits
        decimal = FindDecimal(binary)
        words += chr(decimal)
    return words


def FindDecimal(binary):
    """
    purpose: Takes blocks of 7 bits and convert them into decimals.
    post-condition:set decimal to 0.
    pre-condition: for each block of 7 bits it's convert it to decimals and return it values.
    
    
    """
    dec = 0
    for i in binary:
        dec = dec * 2 + int(i)  # compute and find decimal
    return dec


def ascii7bits_to_binary(word):
    """
    purpose:takes a string of ASCII characters and returns a string 7 bit binary representations for all the ASCII
    characters.
    post-condition:None.
    pre-condition: takes strings of ASCII characters and  uses the built-in ord
    function to convert ASCII character to decimal value, and returns a string of 7 bit binary representations for
    all ASCII characters.
    
    """
    bin = ''
    for i in range(0, len(word)):  # loop through the string
        decimal = ord(word[i])  # convert each string to decimal
        decimal = int(decimal)
        # print(decimal)
        binary = FindBinary(decimal)
        bin += binary
    return bin


def FindBinary(decimal):
    """
    purpose: Takes decimal values and convert them into binary
    post-condition:None
    pre-condition:takes decimal values as arguments and return the binary representation of the decimal values
    """
    temp = ""
    while decimal >= 1:
        temp += str(decimal % 2)
        decimal = (decimal // 2)

    binary = ""
    for i in range(len(temp) - 1, -1, -1):
        binary = binary + temp[i]

    if len(binary) < 7:
        zero = "0000000"
        strbin = len(binary)
        bin = 7 - strbin
        strings = zero[:bin]
        binary = strings + binary
        return binary

    else:
        return binary


def main():
    """
    main drive the overall program operation
    """

    string = input("Input a string to convert:")
    print("String to convert: " + string)
    print("converting to binary")
    strin = ascii7bits_to_binary(string)
    print(strin)
    print("Converting to ASCII")

    strout = binary_to_ascii7bits(strin)
    print(strout)


if __name__ == "__main__":
    main()
