import turtle as tt
import math as mt

"""
file name: Inscrible_poly.py
author: Issah A
drawing inscribleing polygons using recursion and iteration.
"""


def inscrible_poly(radius, sides):
    """"
    purpose:iterative function to draw any polygon of a specified radius pre-condition:pen is down. turtle
    facing east post-condition:position the turtle north, go back by the radius and draw circle and polygon and go
    back at the starting position recursively draw polygons until sides is less then 3 return the distance
    
    """
    distance = 0  # initialize distance to 0
    while sides >= 3:  # iterative function to
        if sides >= 3:  # check to see if sides is less then 3
            distance += circles(radius, sides)  # draw the first circle and pentagon inside the outer circle

            sideA = radius
            Asq = radius * radius
            # print("Asq", Asq)
            sideCsq = 2 * Asq - 2 * Asq * mt.cos(mt.radians(360 / sides))
            # print("sideCsq", sideCsq)
            sideC = mt.sqrt(sideCsq)  # compute side C
            # print("sideC", round(sideC,3))
            rad = mt.sqrt(mt.pow(sideA, 2) - mt.pow((sideC / 2), 2))  # compute the new radius
            # print("rad", rad)

            distance += inscrible_poly(rad, sides - 1)  # recursively draw the polygons until sides is less then 3
            getcolor(sides)  # call color function to set the pen colors

            tt.dot()  # prints point(dot) at the turtle’s pen location
        break  # break out of the while loop
    return distance  # return distance of all polygon sides drawn


def getcolor(sides):
    """
    purpose: function to alternate between three different colors either blue , red or orange
    pre-condition:
    post-condition:divide the sides by three.pen color is set based on remainder 

    """
    if (sides % 3) == 0:  # set the pen color to red since the remainder of sides/3 is 0
        tt.color()
        tt.pencolor("red")
    elif (sides % 3) == 1:  # set the pen color to blue since the remainder of sides/3 is 1
        tt.color()
        tt.pencolor("blue")
    else:  # set the pen color to orange if remainder is not 0 or 1
        tt.color()
        tt.pencolor("orange")


def circles(radius, sides):
    """
    purpose:draw any polygon of a specified radius and sides.
    pre-condition:pen up, turtle facing north.
    post-condition:position the turtle north, go back by the radius and draw circle and polygon and go back at the
    starting position compute the new distance and angle
    
    """
    tt.up()
    tt.lt(90)
    tt.bk(radius)
    tt.rt(90)
    tt.down()
    tt.color("black")
    tt.circle(radius)

    dis = 2 * mt.pow(radius, 2) - 2 * mt.pow(radius, 2) * mt.cos(mt.radians(-360 / sides))  # compute the distance
    dis = mt.sqrt(dis)

    angle = 180 - ((sides - 2) * 180) / sides  # adjust the angle for next turn

    getcolor(sides)
    distance = 0
    tt.lt(angle / 2)
    for i in range(sides):
        tt.fd(dis)
        tt.lt(angle)
        distance += dis  # get the distance polygon sides

    tt.rt(angle / 2)  # adjust the angle
    tt.lt(90)
    tt.up()
    tt.fd(radius)  # go back home
    tt.rt(90)

    return distance  # return the distance of all polygon sides draw


def getinput():
    """
    purpose:get input from the user, check to see if the input is numeric
    return the numeric value is input is numeric
    if not return noneint

    
    """
    sides = input("Enter number of sides(0 to quit):")
    if sides.isnumeric():
        sides = int(sides)
        return sides
    else:
        return "noneint"


def ini():
    """
    purpose:initialization function to set up the canvas and turtle state.
    post-condition::set the turtle pen size to two, set the turtle title.
    """
    tt.pensize(2)
    tt.speed(0)


def main():
    tt.speed(0)
    """
    main drive the overall program operation
    """

    count = 0
    while count != 2:

        sides = getinput()
        tt.clear()
        tt.reset()
        if sides == "noneint":
            print("Error: Input is not an integer")
            break
        elif sides >= 3:
            ini()
            print("Distance of all polygon sides drawn:", inscrible_poly(200, sides))
        elif sides < 3:
            break

        count += 1
    tt.done()


if __name__ == "__main__":
    tt.speed(0)
    main()
