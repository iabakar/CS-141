""" 
squares.py: Square Recursion
assignment: lab 2
language: python3
author: issah A
"""


import turtle as t

def draw1square(size):
    """
    purpose:  draws square
    pre-condition:pen is down. turtle facing east 
    post-condition:turtle is back at the starting position 
    
    """

    t.forward(size)
    t.lt(90)
    t.forward(size)
    t.lt(90)
    t.forward(size)
    t.lt(90)
    t.forward(size)
    t.lt(90)

def draw_square0(size):
    """
     this function does nothing
     Return none
    """
    pass



def draw_square1(size):
    """
    purpose: call draw square0 and draw square
    pre-condition:pen is down. turtle facing east 
    post-condition:call draw square0 and square1 to draw square.
    """
    draw_square0(size)
    draw1square(size)

def draw_square2(size):
    """
    purpose:calls draw square 1 and draw 1 square to draw depth of 2
    pre-condition:pen down. turtle facing east 
    post-condition: draw depth of 2 
    """

    draw_square1(size)
    t.forward(size)
    t.lt(90)
    t.forward(size)
    t.rt(90)
    draw_square1(size/3)
    t.lt(180)
    t.fd(size)
    t.rt(90)
    draw1square(size/3)
    t.bk(size)
    t.rt(90)



def draw_square3(size):
    """
    purpose:call function draw square 1,2,3 to draw depth of 3
    pre-condition:pen down. turtle facing east.
    post-condition: draw depth of 3
    """
    draw_square1(size)
    t.forward(size)
    t.lt(90)
    t.forward(size)
    t.rt(90)
    draw_square2(size/3)
    t.lt(180)
    t.fd(size+size/3)
    t.lt(180)
    draw_square2(size/3)
    t.fd(size/3)
    t.right(90)
    t.fd(size)
    t.lt(90)



def draw_squares(size, depth):
    """
    purpose: Recursive function to draw square for any depth
    pre-condition: pen down. turtle is facing east
    post-condition: draw squares for the given depth
    
    """


    if depth ==0:
        draw_square0(size)
    elif depth >= 1: 
        colors(depth)

        draw_square1(size)
        t.up()
        t.forward(size)
        t.lt(90)
        t.forward(size)
        t.rt(90)
        t.down()
        
        draw_squares(size/3, depth-1)
        colors(depth)

        
        t.up()
        t.bk(size+size/3)
        t.down()
        t.speed(1)
        draw_squares(size/3, depth-1)
        colors(depth)        
        t.up()
        t.fd(size/3)
        t.rt(90)
        t.fd(size)
        t.lt(90)
        t.down()


def colors(depth):
    """
    purpose: function to alternate between two different colors either blue or orange
    pre-condition:
    post-condition:divide the depth by two.if no remainder pen is set to color blue and if there's remainder set the pen color to orange

    
    """
    if (depth%2)==0:
        t.color()
        t.pencolor("blue")
    elif(depth%2)!=0:
        t.color()
        t.pencolor("orange")


def initialization():
    """
    purpose:initialization function to set up the canvas and turtle state.
    post-condition::set the turtle pen size to two, set the turtle title.
    """
    t.pensize(2)
    t.title("Square Recursion")





def main():
    """
    main drive the overall program operation

    """
    depth = int(input("Input recursive depth:"))#ask the user for input and convert the input to integer
    size = input("Input canvas size:") #ask the user for size input
    if size =="":#check to see if the input is null
        size = 600 #set the size to default if the input is none
    else:
        size = int(size)#if not convert the input to integer ans assign it to size
    initialization()    
    t.setup(size,size)#set the canvas siz
    draw_squares(150,depth) #
    print("Please Click the ‘X’ button in the title bar to clos the canvas window.")
    t.done()



if __name__ == "__main__":
    main()






