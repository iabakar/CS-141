import turtle

t = turtle
def draw1square(size):
    t.forward(size)
    t.rt(90)
    t.forward(size)
    t.rt(90)
    t.forward(size)
    t.rt(90)
    t.forward(size)
    t.rt(90)


def draw_square0(size):
    pass

def draw_square1(size):
    draw1square(size)
    draw_square0(size)
    t.fd(size)
    draw_square0(size)
    t.backward(size)

def draw_square2(size):
    draw_square1(size)
    t.up()
    t.bk(size/3)
    t.lt(90)
    t.fd(size/3)
    t.right(90)
    t.down()
    draw_square1(size/3)
    t.fd(size/3)
    t.right(90)
    t.fd(size/3)
    t.lt(90)
    t.fd(size)
    t.lt(90)
    draw_square1(size/3)
    t.up()
    t.lt(90)
    t.fd(size)
    t.rt(90)
    t.fd(size/3)
    t.lt(90)
    t.down()

def draw_square3(size):
    draw_square2(size)
    t.fd(size/3)
    draw1square(size/9)
    t.back(size/3)
    t.right(90)
    draw1square(size/9)
    t.rt(90)
    t.up()
    t.fd(size)
    t.lt(180)
    t.down()
    draw_square1(size/9)
    t.backward(size/3)
    t.rt(90)
    draw_square1(size/9)


def draw_squares(Size):
    draw_square3(Size)




draw_squares(100)
t.done()



