""" 
file: double_add5.py
description: integer sequence 
language: python3
author: Issah A 
"""


def print_sequence_iter(start, count):
    """
    purpose: print a sequence of count steps iteratively.
    param start: initial start of sequence 
    param: count:steps of the sequence from the start value
    """
    print(start, end=" ")  # print start value and end with space

    while count != 0:  # iteratively generates and prints count steps until count is equal to 0
        start = (start * 2 + 5)
        print(start, end=" ")
        count = count - 1

def print_sequence_rec(start, count):
    """
    purpose:print a sequence of count steps recursively.
    param start: initial start of sequence 
    param: count:steps of the sequence from the start value
    
    """
    if count == 0:  # pass if count is 0: which means we reached our goal
        pass
        print(start, end=" ")
    else:
        start = (start * 2 + 5)  # next sequence
        count = count - 1  # subtract count
        print(start, end=" ")  # print the sequence on a single line separated by a single space.
        print_sequence_rec(start, count)  # run the recursive function again


def find_start_forward(goal, count):
    """
    purpose:iteratively searches forward from an initial start value of 0, 
    computes the sequence until the last value is greater than or equal to the goal,
    and returns the start value of the sequence.

    param: count:steps of the sequence from the start value
    param goal:value is greater than or equal to the goal
    
    """
    if count == 0:
        return goal

    start = 0  # initial start value of 0,
    num_count = count  # keep copy of count in new variable num_count
    while start < goal:  #

        num_start = start  # get copy of start
        count = num_count

        while goal >= 0 and count >= 0:

            if num_start >= goal:  # check to see if the last value is greater than or equal to the goal
                return start  # return start value
            else:
                num_start = (num_start * 2) + 5  # if not we iteratively searches forward from the next value
                count = count - 1

        start = start + 1  # add one to start if we cannot reach the goal in count steps and iteratively searches
        # forward again

# print(find_start_forward(100,3))
