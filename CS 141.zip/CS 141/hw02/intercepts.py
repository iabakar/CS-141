"""
file: intercepts.py
author: Issah Abakar
"""

def no_x_intercept(m,b):
    """
    check to see if m is 0: there's no x intercept when x is 0
    if m is 0 the function return True
    if m is not 0 the function retrun False
    """
    if m ==0:
        return True
    elif m !=0:
        return False


def x_intercept(m,b):
    """
    call no_x_intercept function to see if it's either true or false
    if true: the function return None. since there's no x intercept 
    if false: calculte the x intercept and return the value
    """
    no_X = no_x_intercept(m,b)
    if no_X is True:
        return None
    elif no_X is False:
        no_X = -(b)/(m)
        return no_X
   


def y_intercept(m,b):
    """
    return the y intercept
    """
    return b

formatter = "{0:.3f}" #declear value to format three values


def print_point(x,y):
    """
    check to see if x is none
    print none if x is set to none
    format and print the x and y points
    
    """
    if x is None:
        print("(None) ", end="")
    else:
        
        print("("+formatter.format(x)+ ") ("+formatter.format(y)+")", end="")


def test_case(m,b):
    """
    get the values of x and y intercept 
    print equation, x and y intercept, and x and y points
    """
    x = x_intercept(m,b)
    y = y_intercept(m,b)
    
    print("Equation: Y =",str(m)+"X +", str(b)+'. Intercepts: ' ,end="")
    print_point(x,0)
    print_point(0,y) 
    print('\n')


def main():
    """
    main calls test_cases and pass m and b points
    """
    test_case(3,4)
    test_case(-2,8)
    test_case(0,5)
    test_case(1,-7)
    test_case(-4,1)
    test_case(0,2)
    test_case(3,5)
    test_case(-5,3)
    test_case(-4,9)
    test_case(5,-7)




if __name__ == "__main__": #calls the main function if this is the main module.
    main() #call main function
