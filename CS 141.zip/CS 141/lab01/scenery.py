"""
file: scenery.py
author: Issah Abakar
"""

import turtle
t= turtle
def square():
    """
    Make the turtle draw a square.
    :precondition: Pen is down.
    :precondition: Turtle is facing East
    position the turtle for next drawing
    call the windows function to draw windows and door
    """
    t.begin_fill() #begin filli
    t.fillcolor("lightblue") #fill the square box with lightblue color
    # draw the square 
    t.fd(100)
    t.rt(90)
    t.fd(100)
    t.rt(90)
    t.fd(100)
    t.rt(90)
    t.fd(100)
    t.rt(90)
    t.end_fill() #stop filling the square box since we are out of the loop
    t.up()
    t.fd(10)
    t.rt(90)
    t.fd(15)
    t.lt(90)
    t.down()
    windows()

def win_doors():
    """
    draw small square which will be used by the calling fuction to draw small windows 
    """
    t.begin_fill()
    t.fillcolor("white") #set the fill color to white beacuse the house is filled with lightblue color adding white will overright and change it windows to white
    # draw the samll square: which is the windows 
    t.fd(10)
    t.rt(90)
    t.fd(10)
    t.rt(90)
    t.fd(10)
    t.rt(90)
    t.fd(10)
    t.rt(90)
    t.end_fill()


def windows(): 
    """
    draws the five windows and door
    color both windows and door 
    position the turtle for next drawing
    """
    #call the draw windows function to draw three windows up top

    win_doors()
    t.up()     
    t.fd(30)
    t.down()
    win_doors()
    t.up()     
    t.fd(30)
    t.down()
    win_doors()
    t.up()     
    t.fd(30)
    t.down()
    t.up()
    t.backward(20)
    t.rt(90)
    t.fd(40)
    t.down()
    win_doors() #draw the window at the right
    t.fd(10)
    t.rt(90)
    t.up()
    t.fd(60)
    t.down()
    win_doors() #draw the window at the left
    t.up() #lift the pen
    t.home() #Go back to the default direction(0,0 coordinates). turtle facing to east
    t.fd(40)
    t.rt(90)
    t.fd(100)
    t.lt(90)
    t.begin_fill()
    t.color("burlywood") #color the door burlywood
    t.fd(15)
    t.lt(90)
    t.fd(45)
    t.lt(90)
    t.fd(15)
    t.lt(90)
    t.fd(45)
    t.up()
    t.end_fill()
    t.home() #set the turtle back to starting position


def triangle():
    """
    draw triangle
    color the triangle brown
    position the turtle for next drawing
    """
    t.begin_fill()
    t.fillcolor("brown")
    t.fd(100)
    t.lt(120)
    t.fd(100)
    t.lt(120)
    t.fd(100)
    t.lt(120)
    t.end_fill()
    t.up()
    t.bk(50)


def tree():
    """
    draw a single tree
    color the tress 

    """

    t.down()
    t.begin_fill()
    t.color("Brown")
    t.fd(20)
    t.rt(90)
    t.fd(100)
    t.rt(90)
    t.fd(20)
    t.rt(90)
    t.fd(100)
    t.rt(90)


    t.end_fill()
    t.up()
    t.fd(40)
    t.lt(90)
    t.fd(30)
    t.down()
    t.begin_fill()
    t.circle(30)
    t.fillcolor("Green")
    t.end_fill()

def sun():
    """
    draw the Sun in the sky
    color the sun yellow
    set the turtle back to starting position
    
#     """
    t.up()
    t.fd(100)
    t.down()
    t.begin_fill()
    t.fillcolor("Yellow")
    t.circle(20)
    t.end_fill()
    t.up()
    t.home()
    t.fd(140)
    t.down()



def main():
    """
    main drive the overall program operation
    """
    square()#we first draw square, the square function will call draw windows function to draw windows and the door since they are inside the square
    triangle()#we then draw triangle
    tree() 
    sun()
    tree()
    t.up() #pick the pen up
    t.home() #
    t.down()
 

if __name__ == "__main__": #calls the main function if this is the main module.
    main()
    t.done()
