"""
file: hexagons.py
author: Issah Abakar
"""

import turtle

t = turtle
def hexagon():
    """
Make the turtle draw a hexagon.
:precondition: Pen is down.
:precondition: Turtle is facing East
:postcondition: Turtle’s state such as direction, pen position
is the same as when this function started.
"""
    t.forward(60)
    t.left(60)
    t.forward(60)
    t.left(60)
    t.forward(60)
    t.left(60)
    t.forward(60)
    t.left(60)
    t.forward(60)
    t.left(60)
    t.forward(60)
    t.left(60)
    t.up()
    t.forward(60)
    t.down()
    t.right(60)


def initialize():
    """
    function to set pen size to 2 
    """
    t.pensize(2)

def reposition(): 
    """
    function to reposition the turtle state
    """
    t.right(60)


def print_X():
    """"
    print function that instruct the user how to close turtle window
    """
    print(" click on the “X” button in the window titlebar")
def main():
    """
    the Main function call's the initialize to set the pen size
    draw the hexagons
    keep the drawing windows up until the user clicks the X button

    """

    initialize()
    hexagon()
    hexagon()
    hexagon()
    hexagon()
    hexagon()
    hexagon()
    reposition() 
    hexagon()
    hexagon()
    hexagon()
    hexagon()
    hexagon()
    hexagon()
    print_X()

    t.done()

if __name__ == "__main__": #call the main function if this is the main module.
    main()
