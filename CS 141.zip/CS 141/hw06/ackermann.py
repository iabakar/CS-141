"""
CSCI-141: Testing & Debugging
Homework 6
Author:Issah A

This module is production code and is intended for end users to run test.
"""


def ack(m, n):
    """
    :param m: m is non-negative integers arguments,
    :param n: n is non-negative integers arguments,
    :return: returns the results of the Ackermann Function
    """
    if m == 0:
        return n + 1

    elif m > 0 and n == 0:
        return ack(m - 1, 1)
    elif m > 0 and n > 0:
        return ack(m - 1, ack(m, n - 1))


def main():
    """
    Ask the user for input of m and values,
    pass the values to the ack() function,
    get the results of the Ackermann Function and print

    :return:
    """
    m = int(input("Enter M:"))
    n = int(input("Enter N:"))

    results = ack(m, n)
    print("ack(", m, ",", n, ") =", results)


if __name__ == '__main__':
    main()
