"""
CSCI-141: Testing & Debugging
Homework 6
Author: Issah A
run test cases on is palindrome function in the palindrome module
"""

from palindrome import is_palindrome as isp


def test_is_palindrome(name, string, expected):
    """
    A single test of the is_palindrome() function.
    :param name: a string with the function and arguments being tested
    :param string: second is_palindrome() parameter
    :param expected: the expected result
    """

    result = isp(string)
    if result == expected:
        print(name, 'passed')
    else:
        print(name, 'failed; expected', expected, 'but got', result)


def run_tests():
    """"
    this function is used to test a single call to the
    is palindrome function in the palindrome module


    """
    test_is_palindrome("is_palindrome(a)", "a", True)
    test_is_palindrome("is_palindrome(aaa)", "aa", True)
    test_is_palindrome("is_palindrome(aaaa)", "aaaa", True)
    test_is_palindrome("is_palindrome(aaaaa)", "aaaaa", True)
    test_is_palindrome("is_palindrome(aaaaaa)", "aaaaaa", True)
    test_is_palindrome("is_palindrome(b)", "b", True)
    test_is_palindrome("is_palindrome(ababaaba)", "ababaaba", False)
    test_is_palindrome("is_palindrome(bb)", "bb", True)
    test_is_palindrome("is_palindrome(bbb)", "bbb", True)
    test_is_palindrome("is_palindrome(bbbba)", "bbbb", True)
    test_is_palindrome("is_palindrome(bbbb)", "bbbb", True)


if __name__ == '__main__':
    run_tests()
