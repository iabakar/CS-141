""" 
triangles.py: draws Shrinking Triangles
assignment: Homework 3
language: python3
author: issah A
"""



import turtle as t
def triangle(size):
    """
    purpose:  draws Triangle
    pre-condition:pen is down. turtle facing east 
    post-condition:draw triangle and position the tutule for next drawing
    
    """
    t.speed(1)
    t.lt(60)
    t.fd(size)
    t.lt(120)
    t.fd(size)
    t.lt(120)
    t.fd(size)
    t.lt(120)
    t.fd(size)
    t.rt(60)


def triangles(size, depth):
    """
    purpose: Recursive function to draw any depth.
    pre-condition:check to see if the depth is less then 1 or greater then 0
    post-condition:call triangle function to draw the base of the triangle. then draw the recursive triangle for any depth
    """
    if depth <1:
        pass
    elif depth != 0: 
        triangle(size)
        # triangle(size/2)


        # triangles(size/2,depth-1) 
        t.lt(180)
        t.fd(size)
        t.lt(180)
        # triangles(size/2,depth-1)
        t.rt(60)
        t.fd(size)
        t.lt(60)

def initialize():
    """
    purpose:initialization function to set up the canvas and turtle state.
    post-condition::set the turtle pen size to two, set the turtle title.
    """
    t.pensize(2)
    t.title("Shrinking Triangles")

def main():

    """
    main drive the overall program operation
    """
    # depth = int(input("Please input recursion depth:"))
    initialize()
    triangles(100, 2)
    t.done()

if __name__ == "__main__":
    main()